# Vinn FF Panel v2

Build cloud menggunakan GitHub Actions.
1. Upload seluruh isi folder ini ke repository GitHub.
2. Buka tab Actions.
3. Pilih "Build Vinn FF Panel APK".
4. Tekan Run workflow (atau push ke main).
5. Setelah selesai, buka hasil workflow dan download artifact `VinnFFPanel-debug-apk`.

Workflow memakai JDK 17 dan Gradle yang disediakan runner. Wrapper dibuat saat workflow berjalan.
Aplikasi hanya pendamping pengaturan dan tidak menginjeksi atau memodifikasi game.
